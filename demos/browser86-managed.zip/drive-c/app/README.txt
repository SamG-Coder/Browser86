Browser86 managed compatibility demonstration

ManagedForms.exe: click, edit, save and draw using compiled WinForms.
ManagedConsole.exe / ManagedAnyCPU.exe: 28 checks. Arguments: "hello world" second
ManagedVB.exe: compiled VB.NET loop and file output.

All generated files stay in this virtual drive. This is a partial compatibility runtime, not the full .NET Framework.
