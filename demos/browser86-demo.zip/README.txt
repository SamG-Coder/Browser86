Original Browser86 demo programs, compiled from demos/source.
Start with HelloConsole.exe, then apps/WindowStudio.exe.
No commercial binaries or Windows/Wine components are included.
